package personas;

public enum Rubro {
    GASTRONOMIA,
    ELECTRONICA,
    ARTICULOS_HOGAR
}