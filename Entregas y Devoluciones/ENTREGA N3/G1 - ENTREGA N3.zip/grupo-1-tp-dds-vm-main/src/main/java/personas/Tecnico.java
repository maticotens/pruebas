package personas;

import elementos.Heladera;

public class Tecnico {
    private String nroCUIL;
    private String areaCobertura;
    private PersonaHumana persona;


    public void registrarVisita(Heladera heladera, String descripcion, String URLfoto, Boolean incidenteSolucionado){
        //TODO
        //aca tendriamos que generar una visita con los datos que le pasamos
    }
}
