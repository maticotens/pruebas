package personas;

public enum TipoDocumento {
    LE,
    LC,
    DNI
}