package personas;

public enum TipoMedioDeContacto {
    MAIL,
    WHATSAPP,
    TELEFONO
}