package personas;

public enum TipoJuridica {
    GUBERNAMENTAL,
    ONG,
    EMPRESA,
    INSTITUCION
}