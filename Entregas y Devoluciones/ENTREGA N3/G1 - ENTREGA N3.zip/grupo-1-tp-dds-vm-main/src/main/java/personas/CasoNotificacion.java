package personas;

public enum CasoNotificacion {
    N_VIANDAS_EN_HELADERA,
    N_VIANDAS_PARA_LLENAR_HELADERA,
    DESPERFECTO_HELADERA
}
