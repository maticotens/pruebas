package elementos;

public class ReceptorMovimiento {
    private Heladera heladera;

    public void recibirAlerta(){
        // No aclara qué debemos hacer cuando el sistema recibe una alerta.
    }

    public String getTipo(){
        return "null";
    }
}