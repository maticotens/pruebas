package elementos;

public class Visita {
    Heladera heladera;
    String descripcion;
    String URLfoto;
    Boolean incidenteSolucionado;
}
