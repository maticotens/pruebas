package elementos;

public class Alerta extends Incidente{
    private TipoAlerta tipoAlerta;
}
