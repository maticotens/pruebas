package elementos;

public enum TipoAlerta {
    TEMPERATURA,
    FRAUDE,
    FALLA_EN_CONEXION
}
