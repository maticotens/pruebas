package elementos;

import personas.CasoNotificacion;
import personas.Colaborador;

public class Suscripcion {
    Integer cantidadViandasLimite;
    CasoNotificacion casoNotificacion;
    Colaborador colaborador;
}
