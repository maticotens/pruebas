package elementos;

public enum EstadoSolicitud {
    APROBADA,
    FUERA_DE_TIEMPO,
    ABIERTA,
    RECHAZADA
}
