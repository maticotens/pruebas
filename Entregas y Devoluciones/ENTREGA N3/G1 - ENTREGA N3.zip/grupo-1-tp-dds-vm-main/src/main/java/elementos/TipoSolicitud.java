package elementos;

public enum TipoSolicitud {
    APERTURA,
    SOLICITUD_APERTURA
}
