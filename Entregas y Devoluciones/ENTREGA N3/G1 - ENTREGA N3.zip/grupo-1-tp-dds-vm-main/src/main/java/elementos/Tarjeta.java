package elementos;

import java.time.LocalDateTime;

public class Tarjeta {
    private String id;

    public void registrarUso(Heladera heladera){
        // TODO
        // ACA TENEMOS QUE DAR AVISO AL SISTEMA
        // AVISAR A LA HELADERA QUE TIENE QUE ESTAR ABIERTA DE ACA A 3 HORAS
    }
}
