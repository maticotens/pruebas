package config;

public class Config {
    public static final String RUTA_EXPORTACION = "resources\\top10000.txt";
}
