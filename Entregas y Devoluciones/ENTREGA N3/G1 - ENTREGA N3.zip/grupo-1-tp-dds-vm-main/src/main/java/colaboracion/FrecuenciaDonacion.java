package colaboracion;

public enum FrecuenciaDonacion {
    PERIODICA,
    UNICA
}