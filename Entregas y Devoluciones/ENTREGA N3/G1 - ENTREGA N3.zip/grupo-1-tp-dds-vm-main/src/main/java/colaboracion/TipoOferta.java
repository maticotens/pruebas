package colaboracion;

public enum TipoOferta {
    PRODUCTO,
    SERVICIO
}