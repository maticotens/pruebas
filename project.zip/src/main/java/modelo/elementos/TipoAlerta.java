package modelo.elementos;

public enum TipoAlerta {
    FALLA_TEMPERATURA,
    FRAUDE,
    FALLA_EN_CONEXION
}
