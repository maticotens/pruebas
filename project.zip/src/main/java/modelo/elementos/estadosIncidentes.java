package modelo.elementos;

public enum estadosIncidentes {
}
