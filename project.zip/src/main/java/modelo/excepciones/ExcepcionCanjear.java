package modelo.excepciones;

public class ExcepcionCanjear extends RuntimeException {
    public ExcepcionCanjear(String message) {
        super(message);
    }
}
