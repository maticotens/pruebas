package modelo.suscripcion;

public enum TipoSuscripcion {
    QUEDAN_POCAS,
    POCO_ESPACIO,
    DESPERFECTO
}
