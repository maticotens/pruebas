package modelo.personas;

public enum TipoDocumento {
    LE,
    LC,
    DNI
}