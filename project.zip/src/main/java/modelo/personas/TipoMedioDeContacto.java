package modelo.personas;

public enum TipoMedioDeContacto {
    MAIL,
    WHATSAPP,
    TELEGRAM,
    TELEFONO
}