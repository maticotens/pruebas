package modelo.personas;

public enum TipoJuridico {
    GUBERNAMENTAL,
    ONG,
    EMPRESA,
    INSTITUCION
}