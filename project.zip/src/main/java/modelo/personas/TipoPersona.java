package modelo.personas;

public enum TipoPersona {
    PH,
    PJ
}