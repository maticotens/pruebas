package modelo.notificador.whatsApp;

public interface AdapterWhatsApp {

        public void enviarWhatsApp(String mensaje, String destinatario);
        // mensaje + numero destino
}
