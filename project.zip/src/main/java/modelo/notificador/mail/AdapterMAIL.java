package modelo.notificador.mail;

public interface AdapterMAIL {

    public void enviarMAIL(String mensaje, String destinatario, String asunto);
    // mensaje + mail destino
}
