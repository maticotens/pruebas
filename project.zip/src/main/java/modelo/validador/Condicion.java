package modelo.validador;

public interface Condicion {
    public abstract boolean verificarContrasenia(String username, String constrasenia);

}
