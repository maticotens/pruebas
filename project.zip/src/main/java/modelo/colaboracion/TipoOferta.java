package modelo.colaboracion;

public enum TipoOferta {
    PRODUCTO,
    SERVICIO
}