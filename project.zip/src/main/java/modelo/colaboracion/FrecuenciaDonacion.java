package modelo.colaboracion;

public enum FrecuenciaDonacion {
    PERIODICA,
    UNICA
}