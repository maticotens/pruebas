package modelo.colaboracion;

public enum MotivoDistribucion {
    DESPERFECTO,
    FALTA_VIANDAS
}