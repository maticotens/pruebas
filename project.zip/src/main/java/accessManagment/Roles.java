package accessManagment;

public enum Roles {
    USUARIO,
    ADMIN,
    TECNICO,
}
