# Grupo 1 - Diseño de Sistemas

## Integrantes:

María Lucía Gandur  
Joaquín Menazzi  
Agustin Sosa  
Augusto Adrian Gil Tolentino   
Sofía Marques  
Gianlucca Santucho  
Candela Bergé
